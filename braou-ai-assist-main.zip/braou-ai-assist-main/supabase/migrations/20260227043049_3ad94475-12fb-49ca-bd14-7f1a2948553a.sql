
-- Drop the overly permissive public SELECT policy
DROP POLICY IF EXISTS "Allow public read for verification" ON public.institution_users;

-- Create a restrictive policy that denies all public access
-- The edge function will use the service role key to bypass RLS
CREATE POLICY "Deny public access"
ON public.institution_users
FOR SELECT
USING (false);
