-- Add explicit deny policies for write operations on institution_users
CREATE POLICY "Deny public insert"
ON public.institution_users
FOR INSERT
WITH CHECK (false);

CREATE POLICY "Deny public update"
ON public.institution_users
FOR UPDATE
USING (false)
WITH CHECK (false);

CREATE POLICY "Deny public delete"
ON public.institution_users
FOR DELETE
USING (false);