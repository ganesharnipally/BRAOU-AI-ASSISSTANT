
-- Table to store institution master data (students & faculty)
CREATE TABLE public.institution_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  role TEXT NOT NULL CHECK (role IN ('Student', 'Faculty')),
  user_id TEXT NOT NULL UNIQUE,
  login_username TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  location TEXT,
  center_code TEXT NOT NULL,
  admission_number TEXT,
  roll_number TEXT,
  student_email TEXT,
  staff_id TEXT,
  department TEXT,
  official_email TEXT,
  exam_date DATE,
  hall_ticket_status TEXT,
  classes_status TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Indexes for lookup queries
CREATE INDEX idx_institution_users_admission ON public.institution_users (admission_number) WHERE admission_number IS NOT NULL;
CREATE INDEX idx_institution_users_staff_id ON public.institution_users (staff_id) WHERE staff_id IS NOT NULL;
CREATE INDEX idx_institution_users_roll ON public.institution_users (roll_number) WHERE roll_number IS NOT NULL;
CREATE INDEX idx_institution_users_center ON public.institution_users (center_code);
CREATE INDEX idx_institution_users_username ON public.institution_users (login_username);

-- Enable RLS
ALTER TABLE public.institution_users ENABLE ROW LEVEL SECURITY;

-- Public read-only policy (chatbot verification - no auth required)
CREATE POLICY "Allow public read for verification"
ON public.institution_users
FOR SELECT
USING (true);

-- No insert/update/delete for anonymous users - data managed via admin only
