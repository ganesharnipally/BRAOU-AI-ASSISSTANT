import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

// --- IP-based rate limiter (in-memory, per-isolate) ---
const RATE_LIMIT_WINDOW_MS = 60_000; // 1 minute
const RATE_LIMIT_MAX_REQUESTS = 15;   // max requests per window per IP

interface RateBucket {
  count: number;
  resetAt: number;
}

const rateLimitMap = new Map<string, RateBucket>();

function cleanupRateLimitMap() {
  const now = Date.now();
  for (const [key, bucket] of rateLimitMap) {
    if (now > bucket.resetAt) rateLimitMap.delete(key);
  }
}

// Cleanup stale entries every 5 minutes
setInterval(cleanupRateLimitMap, 5 * 60_000);

function checkRateLimit(ip: string): { allowed: boolean; retryAfterSeconds?: number } {
  const now = Date.now();
  const bucket = rateLimitMap.get(ip);

  if (!bucket || now > bucket.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return { allowed: true };
  }

  bucket.count++;
  if (bucket.count > RATE_LIMIT_MAX_REQUESTS) {
    const retryAfterSeconds = Math.ceil((bucket.resetAt - now) / 1000);
    return { allowed: false, retryAfterSeconds };
  }

  return { allowed: true };
}

function getClientIp(req: Request): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("cf-connecting-ip") ||
    req.headers.get("x-real-ip") ||
    "unknown"
  );
}

const ALLOWED_ORIGINS = [
  'https://braou-ai-assist.lovable.app',
  /\.lovable\.app$/,
  /\.lovableproject\.com$/,
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get('origin') || '';
  const isAllowed = ALLOWED_ORIGINS.some(allowed =>
    typeof allowed === 'string' ? allowed === origin : allowed.test(origin)
  );
  return {
    "Access-Control-Allow-Origin": isAllowed ? origin : 'https://braou-ai-assist.lovable.app',
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
    "Vary": "Origin",
  };
}

const BRAOU_LINKS = {
  location: "https://maps.app.goo.gl/T5jnU4ZLbDj2VREk8",
  hall_ticket: "https://www.braouonline.in/MISC/Halltickets.aspx",
  exam_notification: "https://braou.ac.in/examnotification#gsc.tab=0",
  exam_application: "https://www.braouonline.in/Home.aspx",
  official_website: "https://www.braou.ac.in/",
  online_services: "https://www.braouonline.in/",
  study_centre: "https://braou.ac.in/studycentre/2#gsc.tab=0",
};

const SYSTEM_PROMPT = `You are BRAOU Smart Assist, an official AI assistant for Dr. B. R. Ambedkar Open University (BRAOU), Hyderabad.

You must:
- Provide accurate information about BRAOU admissions, courses, exams, fees, hall tickets, results, assignments, revaluation, and academic calendar.
- Direct users to official links when possible.
- Never fabricate exam dates or results.
- If unsure, advise students to check the official website or call the helpdesk.
- Keep responses clear, structured, and concise.
- Use emoji sparingly for readability.
- All links you share MUST be from the official sources listed below.

Key BRAOU Information:
- Official Website: ${BRAOU_LINKS.official_website}
- Online Services: ${BRAOU_LINKS.online_services}
- Phone: 040-23680222, 23680444, 23680555
- Toll-free: 1800-599-0101
- Email: helpdesk@braou.ac.in
- Address: G Ram Reddy Marg, Masthan Nagar, CBI Colony, Jubilee Hills, Hyderabad, Telangana 500033
- Google Maps: ${BRAOU_LINKS.location}
- Timings: 10:30 AM to 5:00 PM (Working Days)
- UGC Recognized Open University
- Programs: UG (BA, BCom, BSc, BCA, BBA), PG (MA, MCom, MSc, MCA, MBA), Diplomas & Certificates
- Exams: June and December sessions

IMPORTANT STRUCTURED RESPONSES:

When user asks about LOCATION, ADDRESS, "where are you located", "office location":
📍 Our Location:
G Ram Reddy Marg, Masthan Nagar, CBI Colony, Jubilee Hills, Hyderabad, Telangana 500033
🔗 View on Google Maps: ${BRAOU_LINKS.location}

When user asks about HALL TICKET, ADMIT CARD, "download hall ticket":
🎫 Hall Ticket Download:
You can download your Hall Ticket from the official portal:
🔗 Download Hall Ticket: ${BRAOU_LINKS.hall_ticket}

When user asks about EXAM NOTIFICATION, "latest notification", "exam updates":
📢 Latest Exam Notifications:
Check the latest exam notifications on the official page:
🔗 Exam Notifications: ${BRAOU_LINKS.exam_notification}

When user asks about EXAM APPLICATION, "apply for exam", "exam registration":
🖊️ Exam Application:
You can apply for exams through the online services portal:
🔗 Apply for Exam: ${BRAOU_LINKS.exam_application}

When user asks about STUDY CENTRE, "study center", "counseling center", "nearest center":
🏫 Study Centres:
Find your nearest study centre and counseling schedules:
🔗 Study Centres: ${BRAOU_LINKS.study_centre}

Format answers as:
📌 Title
Brief explanation
🔗 Relevant official link (when applicable)

Always end with: "For official confirmation, please visit braou.ac.in or call 1800-599-0101."`;

const MAX_MESSAGE_LENGTH = 5000;
const MAX_MESSAGES = 50;
const VALID_ROLES = ["user", "assistant"];

/** Strip HTML tags and control characters from user input */
function sanitizeContent(content: string): string {
  return content
    // Remove HTML tags
    .replace(/<[^>]*>/g, '')
    // Remove control characters (keep newlines and tabs)
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')
    .trim();
}

function validateMessages(data: unknown): { valid: boolean; error?: string; messages?: Array<{ role: string; content: string }> } {
  if (!data || typeof data !== 'object' || !('messages' in (data as Record<string, unknown>))) {
    return { valid: false, error: "Invalid request format" };
  }

  const { messages } = data as { messages: unknown };

  if (!Array.isArray(messages) || messages.length === 0) {
    return { valid: false, error: "Messages must be a non-empty array" };
  }

  if (messages.length > MAX_MESSAGES) {
    return { valid: false, error: "Too many messages in conversation" };
  }

  const sanitized: Array<{ role: string; content: string }> = [];

  for (const msg of messages) {
    if (!msg || typeof msg !== 'object') {
      return { valid: false, error: "Invalid message format" };
    }
    if (typeof msg.role !== 'string' || !VALID_ROLES.includes(msg.role)) {
      return { valid: false, error: "Invalid message role" };
    }
    if (typeof msg.content !== 'string' || msg.content.trim().length === 0) {
      return { valid: false, error: "Message content must be a non-empty string" };
    }
    if (msg.content.length > MAX_MESSAGE_LENGTH) {
      return { valid: false, error: "Message content too long" };
    }

    const cleanContent = sanitizeContent(msg.content);
    if (cleanContent.length === 0) {
      return { valid: false, error: "Message content must be a non-empty string" };
    }

    sanitized.push({ role: msg.role, content: cleanContent });
  }

  return { valid: true, messages: sanitized };
}

serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Rate limiting
  const clientIp = getClientIp(req);
  const rateCheck = checkRateLimit(clientIp);
  if (!rateCheck.allowed) {
    return new Response(
      JSON.stringify({
        error: "Too many requests. Please try again later.",
        retry_after_seconds: rateCheck.retryAfterSeconds,
      }),
      {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }

  try {
    const data = await req.json();
    const validation = validateMessages(data);

    if (!validation.valid) {
      return new Response(JSON.stringify({ error: validation.error }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error("LOVABLE_API_KEY is not configured");
      return new Response(JSON.stringify({ error: "Service temporarily unavailable" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...validation.messages!,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);

      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Too many requests. Please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ error: "Unable to process request. Please try again later." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chat error:", e);
    return new Response(
      JSON.stringify({ error: "An error occurred. Please try again later." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
