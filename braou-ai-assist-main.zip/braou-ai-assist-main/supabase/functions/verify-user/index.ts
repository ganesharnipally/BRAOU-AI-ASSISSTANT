import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  "https://braou-ai-assist.lovable.app",
  /\.lovable\.app$/,
  /\.lovableproject\.com$/,
];

const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX_REQUESTS = 20;

interface RateBucket {
  count: number;
  resetAt: number;
}

const rateLimitMap = new Map<string, RateBucket>();

function checkRateLimit(clientKey: string): { allowed: boolean; retryAfterSeconds?: number } {
  const now = Date.now();
  const bucket = rateLimitMap.get(clientKey);

  if (!bucket || now > bucket.resetAt) {
    rateLimitMap.set(clientKey, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return { allowed: true };
  }

  bucket.count += 1;
  if (bucket.count > RATE_LIMIT_MAX_REQUESTS) {
    return {
      allowed: false,
      retryAfterSeconds: Math.ceil((bucket.resetAt - now) / 1000),
    };
  }

  return { allowed: true };
}

function getClientIp(req: Request): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("cf-connecting-ip") ||
    req.headers.get("x-real-ip") ||
    "unknown"
  );
}

function getCorsHeaders(req: Request) {
  const origin = req.headers.get("origin") || "";
  const isAllowed = ALLOWED_ORIGINS.some((allowed) =>
    typeof allowed === "string" ? allowed === origin : allowed.test(origin)
  );

  return {
    "Access-Control-Allow-Origin": isAllowed ? origin : "https://braou-ai-assist.lovable.app",
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
    "Vary": "Origin",
  };
}

function validateInput(value: string | undefined, maxLength = 50): boolean {
  return (
    typeof value === "string" &&
    value.length > 0 &&
    value.length <= maxLength &&
    /^[A-Za-z0-9\-_@.]+$/.test(value)
  );
}

function cleanInput(input: string, maxLength = 50): string {
  return input.trim().toUpperCase().slice(0, maxLength);
}

serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const clientIp = getClientIp(req);
  const rateCheck = checkRateLimit(clientIp);
  if (!rateCheck.allowed) {
    return new Response(
      JSON.stringify({
        error: "Too many requests. Please try again later.",
        retry_after_seconds: rateCheck.retryAfterSeconds,
      }),
      {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }

  try {
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const payload = await req.json().catch(() => null);
    if (!payload || typeof payload !== "object") {
      return new Response(JSON.stringify({ error: "Invalid request payload" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { type, admission_number, roll_number, center_code, staff_id } = payload as {
      type: "student" | "faculty";
      admission_number?: string;
      roll_number?: string;
      center_code?: string;
      staff_id?: string;
    };

    if (type !== "student" && type !== "faculty") {
      return new Response(JSON.stringify({ error: "Invalid type" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (type === "student") {
      if (!admission_number || !center_code) {
        return new Response(JSON.stringify({ error: "admission_number and center_code are required" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (!validateInput(admission_number, 30) || !validateInput(center_code, 20)) {
        return new Response(JSON.stringify({ error: "Invalid input format" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (roll_number && !validateInput(roll_number, 30)) {
        return new Response(JSON.stringify({ error: "Invalid roll number format" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const cleanAdmission = cleanInput(admission_number, 30);
      const cleanCenter = cleanInput(center_code, 20);

      let query = supabase
        .from("institution_users")
        .select("full_name, location, center_code, admission_number, roll_number, exam_date, hall_ticket_status, classes_status, student_email, gender")
        .ilike("role", "student")
        .ilike("admission_number", cleanAdmission)
        .ilike("center_code", cleanCenter)
        .limit(1);

      if (roll_number) {
        query = query.ilike("roll_number", cleanInput(roll_number, 30));
      }

      const { data, error } = await query.maybeSingle();

      if (error) {
        console.error("Student verification query error:", error);
        return new Response(JSON.stringify({ error: "Lookup failed" }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify(data ? { found: true, data } : { found: false }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!staff_id || !center_code) {
      return new Response(JSON.stringify({ error: "staff_id and center_code are required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!validateInput(staff_id, 20) || !validateInput(center_code, 20)) {
      return new Response(JSON.stringify({ error: "Invalid input format" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const cleanStaffId = cleanInput(staff_id, 20);
    const cleanCenter = cleanInput(center_code, 20);

    const { data, error } = await supabase
      .from("institution_users")
      .select("full_name, location, center_code, staff_id, department, official_email, classes_status, gender")
      .ilike("role", "faculty")
      .ilike("staff_id", cleanStaffId)
      .ilike("center_code", cleanCenter)
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error("Faculty verification query error:", error);
      return new Response(JSON.stringify({ error: "Lookup failed" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify(data ? { found: true, data } : { found: false }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("Verify error:", e);
    return new Response(JSON.stringify({ error: "An error occurred" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
