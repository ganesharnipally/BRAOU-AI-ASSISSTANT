import { useState, useCallback, useRef, useEffect } from "react";

export type FlowState =
  | "welcome"
  | "student_details"
  | "student_menu"
  | "faculty_details"
  | "faculty_menu"
  | "ai_chat";

export interface ChatAction {
  label: string;
  icon?: string;
  value: string;
}

export interface FormField {
  name: string;
  label: string;
  placeholder: string;
  required?: boolean;
}

export interface FlowMessage {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
  actions?: ChatAction[];
  formFields?: FormField[];
  formId?: string;
}

export interface UserContext {
  role?: "student" | "faculty";
  location?: string;
  student_name?: string;
  admission_number?: string;
  center_code?: string;
  roll_number?: string;
  staff_id?: string;
  department?: string;
  staff_email?: string;
  verified?: boolean;
  verifiedData?: Record<string, string | null>;
}

const BRAOU_LINKS = {
  hall_ticket: "https://www.braouonline.in/MISC/Halltickets.aspx",
  exam_notification: "https://braou.ac.in/examnotification#gsc.tab=0",
  exam_application: "https://www.braouonline.in/Home.aspx",
  official_website: "https://www.braou.ac.in/",
  study_centre: "https://braou.ac.in/studycentre/2#gsc.tab=0",
  location: "https://maps.app.goo.gl/T5jnU4ZLbDj2VREk8",
  results: "https://www.braouonline.in/MISC/Results.aspx",
  courses: "https://braou.ac.in/Academic_Programs.aspx",
  schedule: "https://braou.ac.in/examnotification#gsc.tab=0",
};

const VERIFY_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/verify-user`;

const formatDate = () => {
  return new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
};

const makeId = () => (Date.now() + Math.random()).toString();

export const useChatFlow = () => {
  const [flowState, setFlowState] = useState<FlowState>("welcome");
  const [userContext, setUserContext] = useState<UserContext>({});
  const [isTyping, setIsTyping] = useState(false);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const studentVerifyLoadingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const facultyVerifyLoadingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [messages, setMessages] = useState<FlowMessage[]>([
    {
      id: "welcome-1",
      text: `👋 **Welcome to BRAOU Smart Assist**\n📅 Today: ${formatDate()}\n\nPlease select your role to continue:`,
      isBot: true,
      timestamp: new Date(),
      actions: [
        { label: "🎓 Student", value: "role_student" },
        { label: "🏢 Faculty / Staff", value: "role_faculty" },
        { label: "💬 Chat with AI", value: "open_ai_chat_welcome" },
      ],
    },
  ]);

  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      if (studentVerifyLoadingTimeoutRef.current) clearTimeout(studentVerifyLoadingTimeoutRef.current);
      if (facultyVerifyLoadingTimeoutRef.current) clearTimeout(facultyVerifyLoadingTimeoutRef.current);
    };
  }, []);

  const addBotMessage = useCallback(
    (text: string, actions?: ChatAction[], formFields?: FormField[], formId?: string) => {
      const msg: FlowMessage = {
        id: makeId(),
        text,
        isBot: true,
        timestamp: new Date(),
        actions,
        formFields,
        formId,
      };
      setMessages((prev) => [...prev, msg]);
      return msg;
    },
    []
  );

  /** Show typing indicator for `delay` ms, then add the bot message */
  const addBotMessageWithTyping = useCallback(
    (text: string, actions?: ChatAction[], formFields?: FormField[], formId?: string, delay = 1200) => {
      setIsTyping(true);
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = setTimeout(() => {
        setIsTyping(false);
        addBotMessage(text, actions, formFields, formId);
      }, delay);
    },
    [addBotMessage]
  );

  const addUserMessage = useCallback((text: string) => {
    setMessages((prev) => [
      ...prev,
      { id: makeId(), text, isBot: false, timestamp: new Date() },
    ]);
  }, []);

  const showStudentMenu = useCallback(
    (ctx: UserContext) => {
      const loc = ctx.location ? `\n📍 Location: ${ctx.location}` : "";
      const verified = ctx.verified ? `\n✅ Verified: ${ctx.verifiedData?.full_name || ctx.student_name}` : "";
      addBotMessageWithTyping(
        `🎓 **Student Mode Activated**${loc}${verified}\n\nHow can I assist you today?`,
        [
          { label: "📢 Exam Notifications", icon: "📢", value: "student_exam_notifications" },
          { label: "🎫 Hall Ticket", icon: "🎫", value: "student_hall_ticket" },
          { label: "📝 Apply for Exam", icon: "📝", value: "student_application" },
          { label: "📅 Exam Schedule", icon: "📅", value: "student_schedule" },
          { label: "📊 Results", icon: "📊", value: "student_results" },
          { label: "📍 Center Location", icon: "📍", value: "student_location" },
          ...(ctx.verified ? [{ label: "📋 My Details", icon: "📋", value: "student_my_details" }] : []),
          { label: "💬 Chat with AI", icon: "💬", value: "open_ai_chat" },
          { label: "🔄 Change Role", icon: "🔄", value: "change_role" },
        ],
        undefined,
        undefined,
        1500
      );
      setFlowState("student_menu");
    },
    [addBotMessageWithTyping]
  );

  const showFacultyMenu = useCallback(
    (ctx: UserContext) => {
      const loc = ctx.location ? `\n📍 Location: ${ctx.location}` : "";
      const verified = ctx.verified ? `\n✅ Verified: ${ctx.verifiedData?.full_name}` : "";
      addBotMessageWithTyping(
        `🏢 **Faculty Mode Activated**${loc}${verified}\n\nSelect an option:`,
        [
          { label: "📊 Student Records", icon: "📊", value: "faculty_records" },
          { label: "📝 Internal Exam Mgmt", icon: "📝", value: "faculty_exam_mgmt" },
          { label: "📢 Staff Notifications", icon: "📢", value: "faculty_notifications" },
          { label: "🗂 Attendance Reports", icon: "🗂", value: "faculty_attendance" },
          { label: "📄 Administrative Access", icon: "📄", value: "faculty_admin" },
          ...(ctx.verified ? [{ label: "📋 My Details", icon: "📋", value: "faculty_my_details" }] : []),
          { label: "💬 Chat with AI", icon: "💬", value: "open_ai_chat" },
          { label: "🔄 Change Role", icon: "🔄", value: "change_role" },
        ],
        undefined,
        undefined,
        1500
      );
      setFlowState("faculty_menu");
    },
    [addBotMessageWithTyping]
  );

  /** Verify student against the database */
  const verifyStudent = useCallback(
    async (admissionNumber: string, centerCode: string, rollNumber?: string) => {
      setIsTyping(true);

      if (studentVerifyLoadingTimeoutRef.current) {
        clearTimeout(studentVerifyLoadingTimeoutRef.current);
        studentVerifyLoadingTimeoutRef.current = null;
      }

      try {
        const resp = await fetch(VERIFY_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            type: "student",
            admission_number: admissionNumber,
            center_code: centerCode,
            roll_number: rollNumber || undefined,
          }),
        });

        const result = (await resp.json().catch(() => ({}))) as {
          found?: boolean;
          data?: {
            full_name: string;
            admission_number: string;
            center_code: string;
            roll_number: string | null;
            location: string | null;
            gender: string | null;
            exam_date: string | null;
            hall_ticket_status: string | null;
            classes_status: string | null;
            student_email: string | null;
          };
          error?: string;
          retry_after_seconds?: number;
        };

        if (!resp.ok) {
          const retrySuffix = result.retry_after_seconds
            ? ` Please retry after ${result.retry_after_seconds} seconds.`
            : "";
          throw new Error(result.error ? `${result.error}${retrySuffix}` : `Verification failed.${retrySuffix}`);
        }

        if (result.found && result.data) {
          const d = result.data;
          const ctx: UserContext = {
            ...userContext,
            role: "student",
            student_name: d.full_name,
            admission_number: d.admission_number,
            center_code: d.center_code,
            roll_number: d.roll_number ?? undefined,
            location: d.location ?? undefined,
            verified: true,
            verifiedData: d,
          };
          setUserContext(ctx);
          addBotMessage(
            `✅ **Verification Successful!**\n\n` +
              `┌─────────────────────────────\n` +
              `│ 👤 **Name:**        ${d.full_name}\n` +
              `│ 🚻 **Gender:**      ${d.gender || 'N/A'}\n` +
              `│ 📍 **Location:**    ${d.location || 'N/A'}\n` +
              `│ 🆔 **Admission:**   ${d.admission_number}\n` +
              `│ 🔢 **Roll No:**     ${d.roll_number || 'N/A'}\n` +
              `│ 📅 **Exam Date:**   ${d.exam_date || 'N/A'}\n` +
              `│ 🎫 **Hall Ticket:** ${d.hall_ticket_status || 'N/A'}\n` +
              `│ 🏫 **Classes:**     ${d.classes_status || 'N/A'}\n` +
              `└─────────────────────────────`
          );
          showStudentMenu(ctx);
        } else {
          addBotMessage(
            "❌ **No record found.** Please verify your Admission Number and Center Code.\n\nYou can try again or contact the helpdesk at **1800-599-0101**.",
            [
              { label: "🔄 Try Again", value: "skip_location_student" },
              { label: "⬅ Back to Main Menu", value: "change_role" },
            ]
          );
        }
      } catch (error) {
        const errorText = error instanceof Error ? error.message : "";
        const isRateLimited = /too many requests/i.test(errorText);

        addBotMessage(
          isRateLimited
            ? `⏳ You're sending requests too quickly. Please wait a bit and try again.${errorText ? `\n\n${errorText}` : ""}`
            : "⚠️ Verification service is temporarily unavailable. Please try again later or contact **1800-599-0101**.",
          [
            { label: "🔄 Try Again", value: "skip_location_student" },
            { label: "⬅ Back to Main Menu", value: "change_role" },
          ]
        );
      } finally {
        setIsTyping(false);
      }
    },
    [userContext, addBotMessage, showStudentMenu]
  );

  /** Verify faculty against the database */
  const verifyFaculty = useCallback(
    async (staffId: string, centerCode: string) => {
      setIsTyping(true);

      if (facultyVerifyLoadingTimeoutRef.current) {
        clearTimeout(facultyVerifyLoadingTimeoutRef.current);
        facultyVerifyLoadingTimeoutRef.current = null;
      }

      try {
        const resp = await fetch(VERIFY_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            type: "faculty",
            staff_id: staffId,
            center_code: centerCode,
          }),
        });

        const result = (await resp.json().catch(() => ({}))) as {
          found?: boolean;
          data?: {
            full_name: string;
            center_code: string;
            staff_id: string;
            department: string | null;
            official_email: string | null;
            classes_status: string | null;
            gender: string | null;
            location: string | null;
          };
          error?: string;
          retry_after_seconds?: number;
        };

        if (!resp.ok) {
          const retrySuffix = result.retry_after_seconds
            ? ` Please retry after ${result.retry_after_seconds} seconds.`
            : "";
          throw new Error(result.error ? `${result.error}${retrySuffix}` : `Verification failed.${retrySuffix}`);
        }

        if (result.found && result.data) {
          const d = result.data;
          const ctx: UserContext = {
            ...userContext,
            role: "faculty",
            staff_id: d.staff_id,
            department: d.department ?? undefined,
            staff_email: d.official_email ?? undefined,
            location: d.location ?? undefined,
            center_code: d.center_code,
            verified: true,
            verifiedData: d,
          };
          setUserContext(ctx);
          addBotMessage(
            `✅ **Verification Successful!**\n\n` +
              `┌─────────────────────────────\n` +
              `│ 👤 **Name:**       ${d.full_name}\n` +
              `│ 🚻 **Gender:**     ${d.gender || 'N/A'}\n` +
              `│ 📍 **Location:**   ${d.location || 'N/A'}\n` +
              `│ 🆔 **Staff ID:**   ${d.staff_id}\n` +
              `│ 🏢 **Department:** ${d.department || 'N/A'}\n` +
              `│ 📧 **Email:**      ${d.official_email || 'N/A'}\n` +
              `│ 📌 **Status:**     ${d.classes_status || 'N/A'}\n` +
              `└─────────────────────────────`
          );
          showFacultyMenu(ctx);
        } else {
          addBotMessage(
            "❌ **No record found.** Please verify your Staff ID and Center Code.\n\nYou can try again or contact the helpdesk at **1800-599-0101**.",
            [
              { label: "🔄 Try Again", value: "skip_location_faculty" },
              { label: "⬅ Back to Main Menu", value: "change_role" },
            ]
          );
        }
      } catch (error) {
        const errorText = error instanceof Error ? error.message : "";
        const isRateLimited = /too many requests/i.test(errorText);

        addBotMessage(
          isRateLimited
            ? `⏳ You're sending requests too quickly. Please wait a bit and try again.${errorText ? `\n\n${errorText}` : ""}`
            : "⚠️ Verification service is temporarily unavailable. Please try again later or contact **1800-599-0101**.",
          [
            { label: "🔄 Try Again", value: "skip_location_faculty" },
            { label: "⬅ Back to Main Menu", value: "change_role" },
          ]
        );
      } finally {
        setIsTyping(false);
      }
    },
    [userContext, addBotMessage, showFacultyMenu]
  );

  const handleAction = useCallback(
    (value: string) => {
      addUserMessage(
        messages.length > 0
          ? (() => {
              for (const m of [...messages].reverse()) {
                const found = m.actions?.find((a) => a.value === value);
                if (found) return found.label;
              }
              return value;
            })()
          : value
      );

      switch (value) {
        case "role_student":
          setUserContext((prev) => ({ ...prev, role: "student" }));
          addBotMessageWithTyping(
            "📝 Please enter your details for verification:",
            undefined,
            [
              { name: "admission_number", label: "Admission Number", placeholder: "e.g. ADM76703", required: true },
              { name: "center_code", label: "Center Code", placeholder: "e.g. CEN313", required: true },
              { name: "roll_number", label: "Roll Number (Optional)", placeholder: "e.g. ROLL8705", required: false },
            ],
            "student_verify"
          );
          setFlowState("student_details");
          break;

        case "role_faculty":
          setUserContext((prev) => ({ ...prev, role: "faculty" }));
          addBotMessageWithTyping(
            "📝 Please enter your details for verification:",
            undefined,
            [
              { name: "staff_id", label: "Staff ID", placeholder: "e.g. STF3857", required: true },
              { name: "center_code", label: "Center Code", placeholder: "e.g. CEN640", required: true },
            ],
            "faculty_verify"
          );
          setFlowState("faculty_details");
          break;

        // Student sub-blocks
        case "student_exam_notifications":
          addBotMessageWithTyping(
            `📢 **Latest Exam Notifications:**\n\nCheck the latest exam notifications on the official page:\n\n🔗 [View Exam Notifications](${BRAOU_LINKS.exam_notification})`,
            [{ label: "⬅ Back to Menu", value: "back_student_menu" }]
          );
          break;

        case "student_hall_ticket": {
          const htStatus = userContext.verifiedData?.hall_ticket_status;
          const htExtra = htStatus
            ? `\n\n📌 **Your Hall Ticket Status:** ${htStatus}`
            : "";
          addBotMessageWithTyping(
            `🎫 **Download Your Hall Ticket:**\n\nYou can download your Hall Ticket from the official portal:\n\n🔗 [Download Hall Ticket](${BRAOU_LINKS.hall_ticket})${htExtra}`,
            [{ label: "⬅ Back to Menu", value: "back_student_menu" }]
          );
          break;
        }

        case "student_application":
          addBotMessageWithTyping(
            `📝 **Apply for Exam:**\n\nYou can apply for exams through the online services portal:\n\n🔗 [Apply for Exam](${BRAOU_LINKS.exam_application})`,
            [{ label: "⬅ Back to Menu", value: "back_student_menu" }]
          );
          break;

        case "student_schedule": {
          const examDate = userContext.verifiedData?.exam_date;
          const schedExtra = examDate
            ? `\n\n📌 **Your Exam Date:** ${examDate}`
            : "";
          addBotMessageWithTyping(
            `📅 **Exam Schedule:**\n\nCheck the exam schedule and timetable here:\n\n🔗 [View Exam Schedule](${BRAOU_LINKS.schedule})${schedExtra}`,
            [{ label: "⬅ Back to Menu", value: "back_student_menu" }]
          );
          break;
        }

        case "student_results":
          addBotMessageWithTyping(
            `📊 **Check Results:**\n\nView your exam results here:\n\n🔗 [Check Results](${BRAOU_LINKS.results})`,
            [{ label: "⬅ Back to Menu", value: "back_student_menu" }],
            undefined,
            undefined,
            1500
          );
          break;

        case "student_location":
          addBotMessageWithTyping(
            `📍 **Our Center Location:**\n\nG Ram Reddy Marg, Masthan Nagar, CBI Colony, Jubilee Hills, Hyderabad, Telangana 500033\n\n🔗 [View on Google Maps](${BRAOU_LINKS.location})`,
            [{ label: "⬅ Back to Menu", value: "back_student_menu" }]
          );
          break;

        case "student_my_details": {
          const d = userContext.verifiedData;
          if (d) {
            addBotMessageWithTyping(
              `📋 **Your Details:**\n\n` +
              `┌─────────────────────────────\n` +
              `│ 👤 **Name:**        ${d.full_name}\n` +
              `│ 🚻 **Gender:**      ${d.gender || 'N/A'}\n` +
              `│ 📍 **Location:**    ${d.location}\n` +
              `│ 🆔 **Admission:**   ${d.admission_number}\n` +
              `│ 🔢 **Roll No:**     ${d.roll_number}\n` +
              `│ 📅 **Exam Date:**   ${d.exam_date}\n` +
              `│ 🎫 **Hall Ticket:** ${d.hall_ticket_status}\n` +
              `│ 🏫 **Classes:**     ${d.classes_status}\n` +
              `│ 📧 **Email:**       ${d.student_email}\n` +
              `└─────────────────────────────`,
              [{ label: "⬅ Back to Menu", value: "back_student_menu" }]
            );
          }
          break;
        }

        case "back_student_menu":
          showStudentMenu(userContext);
          break;

        // Faculty sub-blocks
        case "faculty_records":
          addBotMessageWithTyping(
            "📊 **Student Records:**\n\nAccess student records through the online services portal:\n\n🔗 [Online Services](https://www.braouonline.in/Home.aspx)",
            [{ label: "⬅ Back to Menu", value: "back_faculty_menu" }]
          );
          break;

        case "faculty_exam_mgmt":
          addBotMessageWithTyping(
            "📝 **Internal Exam Management:**\n\nManage exam-related activities through the admin portal.\n\nFor access, contact the IT department at 040-23680222.",
            [{ label: "⬅ Back to Menu", value: "back_faculty_menu" }]
          );
          break;

        case "faculty_notifications":
          addBotMessageWithTyping(
            `📢 **Staff Notifications:**\n\nCheck latest staff notifications:\n\n🔗 [Official Website](${BRAOU_LINKS.official_website})`,
            [{ label: "⬅ Back to Menu", value: "back_faculty_menu" }]
          );
          break;

        case "faculty_attendance":
          addBotMessageWithTyping(
            "🗂 **Attendance Reports:**\n\nAttendance reports can be accessed through the admin portal.\n\nContact IT support: 040-23680222",
            [{ label: "⬅ Back to Menu", value: "back_faculty_menu" }]
          );
          break;

        case "faculty_admin":
          addBotMessageWithTyping(
            "📄 **Administrative Access:**\n\nFor administrative portal access, please contact:\n\n📞 040-23680222\n📧 helpdesk@braou.ac.in",
            [{ label: "⬅ Back to Menu", value: "back_faculty_menu" }]
          );
          break;

        case "faculty_my_details": {
          const d = userContext.verifiedData;
          if (d) {
            addBotMessageWithTyping(
              `📋 **Your Details:**\n\n` +
              `┌─────────────────────────────\n` +
              `│ 👤 **Name:**       ${d.full_name}\n` +
              `│ 🚻 **Gender:**     ${d.gender || 'N/A'}\n` +
              `│ 📍 **Location:**   ${d.location}\n` +
              `│ 🆔 **Staff ID:**   ${d.staff_id}\n` +
              `│ 🏢 **Department:** ${d.department}\n` +
              `│ 📧 **Email:**      ${d.official_email}\n` +
              `│ 📌 **Status:**     ${d.classes_status}\n` +
              `└─────────────────────────────`,
              [{ label: "⬅ Back to Menu", value: "back_faculty_menu" }]
            );
          }
          break;
        }

        case "back_faculty_menu":
          showFacultyMenu(userContext);
          break;

        // AI Chat (from welcome menu - no role set)
        case "open_ai_chat_welcome":
          setUserContext((prev) => ({ ...prev, role: prev.role || "student" }));
          setFlowState("ai_chat");
          addBotMessageWithTyping(
            "💬 **AI Chat Mode**\n\nYou can now type any question about BRAOU. I'll do my best to help!\n\nType your question below, or go back to the menu.",
            [
              { label: "⬅ Back to Main Menu", value: "change_role" },
            ]
          );
          break;

        // AI Chat (from student/faculty menu)
        case "open_ai_chat":
          setFlowState("ai_chat");
          addBotMessageWithTyping(
            "💬 **AI Chat Mode**\n\nYou can now type any question about BRAOU. I'll do my best to help!\n\nType your question below, or go back to the menu.",
            [
              {
                label: "⬅ Back to Menu",
                value: userContext.role === "student" ? "back_student_menu" : "back_faculty_menu",
              },
            ]
          );
          break;

        case "change_role":
          setUserContext({});
          setMessages([
            {
              id: makeId(),
              text: `👋 **Welcome to BRAOU Smart Assist**\n📅 Today: ${formatDate()}\n\nPlease select your role to continue:`,
              isBot: true,
              timestamp: new Date(),
              actions: [
                { label: "🎓 Student", value: "role_student" },
                { label: "🏢 Faculty / Staff", value: "role_faculty" },
                { label: "💬 Chat with AI", value: "open_ai_chat_welcome" },
              ],
            },
          ]);
          setFlowState("welcome");
          break;

        default:
          break;
      }
    },
    [messages, addUserMessage, addBotMessageWithTyping, showStudentMenu, showFacultyMenu, userContext]
  );

  const handleFormSubmit = useCallback(
    (formId: string, data: Record<string, string>) => {
      switch (formId) {
        case "student_verify": {
          const adm = data.admission_number?.trim();
          const cc = data.center_code?.trim();
          const roll = data.roll_number?.trim();
          if (!adm || !cc) {
            addBotMessage("⚠️ Admission Number and Center Code are required.", undefined);
            return;
          }
          addUserMessage(`🆔 ${adm} | 🏫 ${cc}${roll ? ` | 🔢 ${roll}` : ""}`);
          const loadingMessage = addBotMessage("🔍 Checking your details...");

          if (studentVerifyLoadingTimeoutRef.current) {
            clearTimeout(studentVerifyLoadingTimeoutRef.current);
          }

          studentVerifyLoadingTimeoutRef.current = setTimeout(() => {
            setMessages((prev) =>
              prev.map((msg) =>
                msg.id === loadingMessage.id ? { ...msg, text: "📂 Retrieving your records..." } : msg
              )
            );
          }, 800);

          verifyStudent(adm, cc, roll);
          break;
        }

        case "faculty_verify": {
          const sid = data.staff_id?.trim();
          const cc = data.center_code?.trim();
          if (!sid || !cc) {
            addBotMessage("⚠️ Staff ID and Center Code are required.", undefined);
            return;
          }
          addUserMessage(`🆔 ${sid} | 🏫 ${cc}`);
          const loadingMessage = addBotMessage("🔍 Verifying your credentials...");

          if (facultyVerifyLoadingTimeoutRef.current) {
            clearTimeout(facultyVerifyLoadingTimeoutRef.current);
          }

          facultyVerifyLoadingTimeoutRef.current = setTimeout(() => {
            setMessages((prev) =>
              prev.map((msg) =>
                msg.id === loadingMessage.id ? { ...msg, text: "📂 Retrieving your records..." } : msg
              )
            );
          }, 800);

          verifyFaculty(sid, cc);
          break;
        }

        case "location_student": {
          const loc = data.location?.trim() || "";
          const ctx = { ...userContext, location: loc || undefined };
          setUserContext(ctx);
          if (loc) addUserMessage(`📍 ${loc}`);
          addBotMessageWithTyping(
            "Please enter your details:",
            undefined,
            [
              { name: "student_name", label: "Full Name", placeholder: "Enter your full name", required: true },
              { name: "admission_number", label: "Admission Number", placeholder: "Enter admission number", required: true },
              { name: "center_code", label: "Center Code", placeholder: "Enter center code", required: true },
            ],
            "student_info"
          );
          break;
        }

        case "location_faculty": {
          const loc = data.location?.trim() || "";
          const ctx = { ...userContext, location: loc || undefined };
          setUserContext(ctx);
          if (loc) addUserMessage(`📍 ${loc}`);
          addBotMessageWithTyping(
            "Please enter your details:",
            undefined,
            [
              { name: "staff_id", label: "Staff ID", placeholder: "Enter your staff ID", required: true },
              { name: "department", label: "Department", placeholder: "Enter department", required: true },
              { name: "staff_email", label: "Official Email", placeholder: "Enter official email", required: true },
            ],
            "faculty_info"
          );
          break;
        }

        case "student_info": {
          const ctx = {
            ...userContext,
            student_name: data.student_name,
            admission_number: data.admission_number,
            center_code: data.center_code,
          };
          setUserContext(ctx);
          addUserMessage(`👤 ${data.student_name}\n🆔 ${data.admission_number}\n🏫 ${data.center_code}`);
          showStudentMenu(ctx);
          break;
        }

        case "faculty_info": {
          const ctx = {
            ...userContext,
            staff_id: data.staff_id,
            department: data.department,
            staff_email: data.staff_email,
          };
          setUserContext(ctx);
          addUserMessage(`🆔 ${data.staff_id}\n🏢 ${data.department}\n📧 ${data.staff_email}`);
          showFacultyMenu(ctx);
          break;
        }

        default:
          break;
      }
    },
    [userContext, addUserMessage, addBotMessage, addBotMessageWithTyping, showStudentMenu, showFacultyMenu, verifyStudent, verifyFaculty]
  );

  return {
    flowState,
    messages,
    isTyping,
    userContext,
    handleAction,
    handleFormSubmit,
    addBotMessage,
    addUserMessage,
    setMessages,
  };
};
