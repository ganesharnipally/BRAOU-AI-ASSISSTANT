import { useState, useCallback } from "react";

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;

export const useChatbot = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello! 👋 Welcome to BRAOU Smart Assist. I'm here to help you with admissions, courses, exams, fees, and more. How can I assist you today?",
      isBot: true,
      timestamp: new Date(),
    },
  ]);
  const [isTyping, setIsTyping] = useState(false);

  const sendMessage = useCallback(async (text: string) => {
    const userMsg: Message = {
      id: Date.now().toString(),
      text,
      isBot: false,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setIsTyping(true);

    // Build conversation history for context
    const chatHistory = messages
      .filter((m) => m.id !== "1") // skip welcome
      .map((m) => ({
        role: (m.isBot ? "assistant" : "user") as "assistant" | "user",
        content: m.text,
      }));
    chatHistory.push({ role: "user", content: text });

    let assistantText = "";
    const assistantId = (Date.now() + 1).toString();

    try {
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ messages: chatHistory }),
      });

      if (!resp.ok) {
        const errorPayload = await resp.json().catch(() => null) as
          | { error?: string; retry_after_seconds?: number }
          | null;
        const errorMessage = errorPayload?.error ?? "Failed to get response";
        const retryAfter = errorPayload?.retry_after_seconds;
        const retrySuffix = retryAfter ? ` Retry after ${retryAfter} seconds.` : "";
        throw new Error(`${resp.status}:${errorMessage}${retrySuffix}`);
      }

      if (!resp.body) {
        throw new Error("500:Failed to get response stream");
      }

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let streamDone = false;

      while (!streamDone) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, newlineIndex);
          buffer = buffer.slice(newlineIndex + 1);

          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") {
            streamDone = true;
            break;
          }

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) {
              assistantText += content;
              setMessages((prev) => {
                const last = prev[prev.length - 1];
                if (last?.id === assistantId) {
                  return prev.map((m) =>
                    m.id === assistantId ? { ...m, text: assistantText } : m
                  );
                }
                return [
                  ...prev,
                  { id: assistantId, text: assistantText, isBot: true, timestamp: new Date() },
                ];
              });
            }
          } catch {
            buffer = line + "\n" + buffer;
            break;
          }
        }
      }
    } catch (e) {
      console.error("Chat error:", e);
      const errorText = e instanceof Error ? e.message : "Unexpected error";
      const isRateLimited = errorText.startsWith("429:");

      setMessages((prev) => [
        ...prev,
        {
          id: assistantId,
          text: isRateLimited
            ? `⏳ You're sending requests too quickly right now. Please wait a few seconds and try again.\n\n${errorText.replace(/^429:/, "")}`
            : "I'm sorry, I encountered an error. Please try again or contact the helpdesk at 040-23680222.",
          isBot: true,
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  }, [messages]);

  return {
    messages,
    isTyping,
    sendMessage,
  };
};
