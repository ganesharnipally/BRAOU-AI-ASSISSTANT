import { Chatbot } from "@/components/chat/Chatbot";
import { BookOpen, GraduationCap, Users, Award, Phone, Mail, MapPin, ExternalLink, Navigation, Bot, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import braouLogo from "@/assets/braou-logo.jpeg";
import { useState } from "react";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 flex items-center justify-between h-16">
          <a href="/" className="flex items-center gap-3">
            <img src="/lovable-uploads/a8a0663b-7e2f-4336-97b7-0024abaa2c10.png" alt="BRAOU Logo" className="w-10 h-10 rounded-lg object-contain" />
            <span className="font-bold text-foreground text-lg hidden sm:inline">Dr. B.R. Ambedkar Open University Ai Powered Smart Chatbot Assisstant</span>
          </a>
          <div className="flex items-center gap-3">
            <nav className="flex items-center gap-1 sm:gap-2">
              <Button variant="ghost" size="sm" asChild>
                
              </Button>
              <Button variant="ghost" size="sm" asChild>
                
              </Button>
              <Button variant="ghost" size="sm" asChild>
                
              </Button>
              <Button variant="ghost" size="sm" asChild>
                <a href="#contact" className="scroll-smooth border-solid">Contact</a>
              </Button>
            </nav>
            <div className="flex items-center gap-2 ml-2 border-l border-border pl-3">
              <button className="relative p-2 rounded-full hover:bg-muted transition-colors" aria-label="Notifications">
                <Bell className="w-5 h-5 text-muted-foreground" />
              </button>
              <button
                onClick={() => window.dispatchEvent(new Event('open-chatbot'))}
                className="relative p-2 rounded-full bg-primary/10 hover:bg-primary/20 transition-all duration-300 hover:scale-110 hover:shadow-md hover:shadow-primary/20 group"
                aria-label="Open AI Assistant">

                <Bot className="w-5 h-5 text-primary group-hover:text-primary transition-colors" />
                <span className="absolute top-0.5 right-0.5 w-2.5 h-2.5 bg-accent rounded-full border border-background" />
              </button>
            </div>
          </div>
        </div>
      </header>
















      {/* Hero Section */}
      <section className="gradient-hero py-16 sm:py-24 relative overflow-hidden border-double border-primary">
        {/* Watermark Logo */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <img
            alt=""
            src="/lovable-uploads/a8a0663b-7e2f-4336-97b7-0024abaa2c10.png"
            className="w-[400px] h-[400px] sm:w-[500px] sm:h-[500px] lg:w-[600px] lg:h-[600px] object-contain opacity-[0.07]" />

        </div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <img alt="BRAOU Logo" className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl object-contain mx-auto mb-4" src="/lovable-uploads/a8a0663b-7e2f-4336-97b7-0024abaa2c10.png" />
          <div className="inline-flex items-center gap-2 bg-primary-light text-primary rounded-full px-4 py-2 text-sm font-medium mb-6">
            <GraduationCap className="w-4 h-4" />
            <span>UGC Recognized Open University</span>
          </div>
          <p className="text-primary font-semibold text-sm sm:text-base tracking-widest uppercase mb-3">
            "Education at Your Doorstep"
          </p>
          <h2 className="font-sans text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4 leading-tight">
            Welcome to BRAOU <br className="hidden sm:block" />
            <span className="text-primary">Online Services</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
            Dr. B.R. Ambedkar Open University provides quality distance education. 
            Get instant assistance with our AI-powered chatbot.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" asChild>
              <a target="_blank" rel="noopener noreferrer" href="https://braou.ac.in/#gsc.tab=0">Home page</a>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a target="_blank" rel="noopener noreferrer" href="https://braou.ac.in/admissionsnotification#gsc.tab=0" className="bg-sidebar-primary text-primary-foreground opacity-100">Notifications</a>
            </Button>
            <Button
              size="lg"
              onClick={() => window.dispatchEvent(new Event('open-chatbot'))}
              className="gap-2">

              <Bot className="w-5 h-5" />
              Chat with AI
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 sm:py-20">
        <div className="container mx-auto px-4">
          <h3 className="font-sans text-2xl font-bold text-center text-foreground mb-12">
            How Can We Help You?
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
            {
              icon: BookOpen,
              title: "Course Information",
              description: "Explore UG, PG & Diploma programs offered by BRAOU",
              href: "https://braou.ac.in/Academic_Programs.aspx"
            },
            {
              icon: GraduationCap,
              title: "Admissions",
              description: "Step-by-step guidance for the admission process",
              href: "https://www.braouonline.in/Home.aspx"
            },
            {
              icon: Users,
              title: "Study Centers",
              description: "Find study centers and counseling schedules",
              href: "https://braou.ac.in/studycentre/2#gsc.tab=0"
            },
            {
              icon: Award,
              title: "Examinations",
              description: "Hall tickets, date sheets and results",
              href: "https://braou.ac.in/examnotification#gsc.tab=0"
            }].
            map((feature, index) =>
            <a
              key={index}
              href={feature.href}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-card border border-border rounded-xl p-6 hover:shadow-lg hover:border-primary/30 transition-all duration-300 group block">

                <div className="w-12 h-12 bg-primary-light rounded-lg flex items-center justify-center mb-4 group-hover:gradient-primary transition-all duration-300">
                  <feature.icon className="w-6 h-6 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
                </div>
                <h4 className="font-sans font-semibold text-foreground mb-2 flex items-center gap-2">{feature.title} <ExternalLink className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" /></h4>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </a>
            )}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-secondary/50">
        <div className="container mx-auto px-4">
          <div className="bg-card rounded-2xl p-8 sm:p-12 border border-border">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h3 className="font-sans text-2xl font-bold text-foreground mb-4">
                  Contact Helpdesk
                </h3>
                <p className="text-muted-foreground mb-6">
                  Our support team is available during working hours to assist you with any queries.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary-light rounded-lg flex items-center justify-center">
                      <Phone className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Phone</p>
                      <p className="font-medium text-foreground">040-23680222, 444, 555</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary-light rounded-lg flex items-center justify-center">
                      <Phone className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Toll Free</p>
                      <p className="font-medium text-foreground">1800-599-0101</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary-light rounded-lg flex items-center justify-center">
                      <Mail className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Email</p>
                      <p className="font-medium text-foreground">helpdesk@braou.ac.in</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="bg-primary-light rounded-xl p-6 text-center">
                  <MapPin className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h4 className="font-sans font-semibold text-foreground mb-2">Visit Us</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    G Ram Reddy Marg, Masthan Nagar,<br />
                    CBI Colony, Jubilee Hills,<br />
                    Hyderabad, Telangana 500033
                  </p>
                  <Button size="sm" variant="outline" asChild className="gap-2">
                    <a href="https://maps.app.goo.gl/T5jnU4ZLbDj2VREk8" target="_blank" rel="noopener noreferrer">
                      <Navigation className="w-4 h-4" /> View on Google Maps
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img src={braouLogo} alt="BRAOU Logo" className="w-8 h-8 rounded object-contain" />
              <p className="text-sm text-muted-foreground">
                © {new Date().getFullYear()} Dr. B.R. Ambedkar Open University
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span>Timings: 10:30 AM – 5:00 PM (Working Days)</span>
              <a
                href="https://maps.app.goo.gl/T5jnU4ZLbDj2VREk8"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-primary hover:underline">

                <MapPin className="w-3 h-3" /> Our Location
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Chatbot */}
      <Chatbot />
    </div>);

};

export default Index;