import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Send } from "lucide-react";
import { type FormField } from "@/hooks/useChatFlow";

interface ChatFormProps {
  formId: string;
  fields: FormField[];
  onSubmit: (formId: string, data: Record<string, string>) => void;
  disabled?: boolean;
}

export const ChatForm = ({ formId, fields, onSubmit, disabled }: ChatFormProps) => {
  const [values, setValues] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div className="mt-3 text-xs text-muted-foreground italic">✅ Details submitted</div>
    );
  }

  const handleSubmit = () => {
    // Validate required fields
    for (const f of fields) {
      if (f.required && !values[f.name]?.trim()) return;
    }
    setSubmitted(true);
    onSubmit(formId, values);
  };

  return (
    <div className="mt-3 space-y-3 bg-secondary/30 rounded-xl p-3 border border-border/50">
      {fields.map((field) => (
        <div key={field.name} className="space-y-1">
          <Label className="text-xs font-medium">
            {field.label} {field.required && <span className="text-destructive">*</span>}
          </Label>
          <Input
            placeholder={field.placeholder}
            value={values[field.name] || ""}
            onChange={(e) => setValues((prev) => ({ ...prev, [field.name]: e.target.value }))}
            disabled={disabled}
            className="h-9 text-sm bg-background"
          />
        </div>
      ))}
      <Button
        size="sm"
        onClick={handleSubmit}
        disabled={disabled}
        className="w-full gap-2"
      >
        <Send className="w-3.5 h-3.5" />
        Submit
      </Button>
    </div>
  );
};
