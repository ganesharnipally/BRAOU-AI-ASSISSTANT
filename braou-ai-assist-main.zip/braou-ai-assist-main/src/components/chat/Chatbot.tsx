import { useState, useEffect, useCallback } from "react";
import { ChatButton } from "./ChatButton";
import { ChatWindow } from "./ChatWindow";
import { useChatFlow } from "@/hooks/useChatFlow";

export const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const flow = useChatFlow();

  const handleToggle = useCallback(() => {
    setIsOpen((prev) => !prev);
  }, []);

  useEffect(() => {
    const handler = () => setIsOpen(true);
    window.addEventListener("open-chatbot", handler);
    return () => window.removeEventListener("open-chatbot", handler);
  }, []);

  // "Who built you?" detection
  const CREATOR_PATTERNS = /who\s+(built|created|made|developed|is\s+your\s+(founder|developer|creator))/i;

  // In AI chat mode, send to AI and add responses to flow messages
  const handleSendMessage = useCallback(
    async (text: string) => {
      if (flow.flowState === "ai_chat") {
        flow.addUserMessage(text);

        // Check for "who built you?" type questions
        if (CREATOR_PATTERNS.test(text)) {
          flow.addBotMessage(
            "🤖 I was built and developed by **MR. Arnipally Ganesh**.",
            [
              {
                label: "⬅ Back to Menu",
                value: flow.userContext.role === "student" ? "back_student_menu" : "back_faculty_menu",
              },
            ]
          );
          return;
        }

        // Use AI chatbot for response
        const assistantId = (Date.now() + 1).toString();
        const backAction = flow.userContext.role === "student" ? "back_student_menu" : "back_faculty_menu";

        try {
          const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;
          const chatHistory = flow.messages
            .filter((m) => m.id !== "welcome-1")
            .slice(-20)
            .map((m) => ({
              role: (m.isBot ? "assistant" : "user") as "assistant" | "user",
              content: m.text,
            }));
          chatHistory.push({ role: "user", content: text });

          const resp = await fetch(CHAT_URL, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
            },
            body: JSON.stringify({ messages: chatHistory }),
          });

          if (!resp.ok) {
            const errorPayload = (await resp.json().catch(() => null)) as
              | { error?: string; retry_after_seconds?: number }
              | null;
            const retrySuffix = errorPayload?.retry_after_seconds
              ? ` Retry after ${errorPayload.retry_after_seconds} seconds.`
              : "";
            throw new Error(`${resp.status}:${errorPayload?.error ?? "Failed to get response"}${retrySuffix}`);
          }

          if (!resp.body) {
            throw new Error("500:Failed to get response stream");
          }

          let assistantText = "";
          const reader = resp.body.getReader();
          const decoder = new TextDecoder();
          let buffer = "";

          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });

            let newlineIndex: number;
            while ((newlineIndex = buffer.indexOf("\n")) !== -1) {
              let line = buffer.slice(0, newlineIndex);
              buffer = buffer.slice(newlineIndex + 1);

              if (line.endsWith("\r")) line = line.slice(0, -1);
              if (line.startsWith(":") || line.trim() === "") continue;
              if (!line.startsWith("data: ")) continue;

              const jsonStr = line.slice(6).trim();
              if (jsonStr === "[DONE]") break;

              try {
                const parsed = JSON.parse(jsonStr);
                const content = parsed.choices?.[0]?.delta?.content as string | undefined;
                if (content) {
                  assistantText += content;
                  flow.setMessages((prev) => {
                    const last = prev[prev.length - 1];
                    if (last?.id === assistantId) {
                      return prev.map((m) =>
                        m.id === assistantId
                          ? { ...m, text: assistantText, actions: [{ label: "⬅ Back to Menu", value: backAction }] }
                          : m
                      );
                    }
                    return [
                      ...prev,
                      {
                        id: assistantId,
                        text: assistantText,
                        isBot: true,
                        timestamp: new Date(),
                        actions: [{ label: "⬅ Back to Menu", value: backAction }],
                      },
                    ];
                  });
                }
              } catch {
                buffer = line + "\n" + buffer;
                break;
              }
            }
          }
        } catch (e) {
          const errorText = e instanceof Error ? e.message : "Unexpected error";
          const isRateLimited = errorText.startsWith("429:") || /too many requests/i.test(errorText);

          flow.setMessages((prev) => [
            ...prev,
            {
              id: assistantId,
              text: isRateLimited
                ? `⏳ You're sending requests too quickly right now. Please wait a few seconds and try again.\n\n${errorText.replace(/^429:/, "")}`
                : "I'm sorry, I encountered an error. Please try again or call 1800-599-0101.",
              isBot: true,
              timestamp: new Date(),
              actions: [{ label: "⬅ Back to Menu", value: backAction }],
            },
          ]);
        }
      }
    },
    [flow]
  );

  return (
    <>
      <ChatWindow
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        messages={flow.messages}
        isTyping={flow.isTyping}
        flowState={flow.flowState}
        onSendMessage={handleSendMessage}
        onAction={flow.handleAction}
        onFormSubmit={flow.handleFormSubmit}
      />
      <ChatButton isOpen={isOpen} onClick={handleToggle} />
    </>
  );
};
