import { Bot, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ChatButtonProps {
  isOpen: boolean;
  onClick: () => void;
  hasUnread?: boolean;
}

export const ChatButton = ({ isOpen, onClick, hasUnread }: ChatButtonProps) => {
  return (
    <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50">
      <Button
        variant="chat"
        size="chat"
        onClick={onClick}
        className={cn(
          "relative transition-all duration-300 w-16 h-16 sm:w-[4.5rem] sm:h-[4.5rem] rounded-full shadow-lg hover:shadow-primary/40 hover:scale-110",
          !isOpen && "animate-float"
        )}
      >
        <div
          className={cn(
            "transition-all duration-300",
            isOpen ? "rotate-90 scale-0" : "rotate-0 scale-100"
          )}
        >
          <Bot className="w-8 h-8 sm:w-9 sm:h-9" />
        </div>
        <div
          className={cn(
            "absolute inset-0 flex items-center justify-center transition-all duration-300",
            isOpen ? "rotate-0 scale-100" : "-rotate-90 scale-0"
          )}
        >
          <X className="w-7 h-7" />
        </div>

        {/* Online status indicator */}
        {!isOpen && (
          <span className="absolute top-1 right-1 w-3.5 h-3.5 bg-accent rounded-full border-2 border-background">
            <span className="absolute inset-0 bg-accent rounded-full animate-ping opacity-75" />
          </span>
        )}

        {hasUnread && !isOpen && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-accent rounded-full flex items-center justify-center">
            <span className="w-2.5 h-2.5 bg-accent-foreground rounded-full animate-pulse" />
          </span>
        )}
      </Button>

      {!isOpen && (
        <div className="absolute bottom-full right-0 mb-3 bg-card px-4 py-2.5 rounded-xl shadow-lg border border-border/50 whitespace-nowrap animate-slide-up">
          <p className="text-sm font-medium text-foreground">Need help? 👋</p>
          <div className="absolute bottom-0 right-7 transform translate-y-1/2 rotate-45 w-2.5 h-2.5 bg-card border-r border-b border-border/50" />
        </div>
      )}
    </div>
  );
};
