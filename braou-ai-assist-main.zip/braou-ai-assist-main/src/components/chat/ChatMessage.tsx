import { cn } from "@/lib/utils";
import { User } from "lucide-react";
import ReactMarkdown from "react-markdown";
import braouLogo from "@/assets/braou-logo.jpeg";
import { ChatActions } from "./ChatActions";
import { ChatForm } from "./ChatForm";
import { type ChatAction, type FormField } from "@/hooks/useChatFlow";

interface ChatMessageProps {
  message: string;
  isBot: boolean;
  timestamp?: Date;
  actions?: ChatAction[];
  formFields?: FormField[];
  formId?: string;
  onAction?: (value: string) => void;
  onFormSubmit?: (formId: string, data: Record<string, string>) => void;
  isLatest?: boolean;
}

export const ChatMessage = ({
  message,
  isBot,
  timestamp,
  actions,
  formFields,
  formId,
  onAction,
  onFormSubmit,
  isLatest,
}: ChatMessageProps) => {
  return (
    <div
      className={cn(
        "flex gap-3 animate-message",
        isBot ? "justify-start" : "justify-end"
      )}
    >
      {isBot && (
        <img src={braouLogo} alt="BRAOU" className="flex-shrink-0 w-8 h-8 rounded-full object-contain bg-white border border-border" />
      )}

      <div
        className={cn(
          "max-w-[85%] rounded-2xl px-4 py-3",
          isBot
            ? "bg-chat-bot text-chat-bot-foreground rounded-tl-md"
            : "bg-chat-user text-chat-user-foreground rounded-tr-md"
        )}
      >
        {isBot ? (
          <div className="text-sm leading-relaxed prose prose-sm max-w-none prose-p:my-1 prose-ul:my-1 prose-li:my-0 prose-headings:my-1 prose-a:text-primary prose-a:underline hover:prose-a:no-underline">
            <ReactMarkdown
              components={{
                a: ({ href, children }) => (
                  <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary underline hover:no-underline transition-colors">
                    {children}
                  </a>
                ),
              }}
            >
              {message}
            </ReactMarkdown>
          </div>
        ) : (
          <p className="text-sm leading-relaxed whitespace-pre-wrap">{message}</p>
        )}

        {/* Inline form */}
        {isBot && formFields && formId && isLatest && onFormSubmit && (
          <ChatForm formId={formId} fields={formFields} onSubmit={onFormSubmit} />
        )}

        {/* Action buttons */}
        {isBot && actions && isLatest && onAction && (
          <ChatActions actions={actions} onAction={onAction} />
        )}

        {timestamp && (
          <p
            className={cn(
              "text-xs mt-2 opacity-60",
              isBot ? "text-muted-foreground" : "text-primary-foreground/70"
            )}
          >
            {timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </p>
        )}
      </div>

      {!isBot && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
          <User className="w-4 h-4 text-secondary-foreground" />
        </div>
      )}
    </div>
  );
};
