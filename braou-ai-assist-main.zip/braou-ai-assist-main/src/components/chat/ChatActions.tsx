import { Button } from "@/components/ui/button";
import { type ChatAction } from "@/hooks/useChatFlow";

interface ChatActionsProps {
  actions: ChatAction[];
  onAction: (value: string) => void;
  disabled?: boolean;
}

export const ChatActions = ({ actions, onAction, disabled }: ChatActionsProps) => {
  return (
    <div className="flex flex-wrap gap-2 mt-3">
      {actions.map((action) => (
        <Button
          key={action.value}
          variant="quickAction"
          size="sm"
          onClick={() => onAction(action.value)}
          disabled={disabled}
          className="px-3 py-1.5 h-auto text-xs font-medium"
        >
          {action.label}
        </Button>
      ))}
    </div>
  );
};
