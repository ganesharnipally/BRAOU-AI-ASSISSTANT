import { useRef, useEffect } from "react";
import { X, Minimize2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ChatMessage } from "./ChatMessage";
import { ChatInput } from "./ChatInput";
import { TypingIndicator } from "./TypingIndicator";
import braouLogo from "@/assets/braou-logo.jpeg";
import { type FlowMessage, type FlowState } from "@/hooks/useChatFlow";

interface ChatWindowProps {
  isOpen: boolean;
  onClose: () => void;
  messages: FlowMessage[];
  isTyping: boolean;
  flowState: FlowState;
  onSendMessage: (message: string) => void;
  onAction: (value: string) => void;
  onFormSubmit: (formId: string, data: Record<string, string>) => void;
}

export const ChatWindow = ({
  isOpen,
  onClose,
  messages,
  isTyping,
  flowState,
  onSendMessage,
  onAction,
  onFormSubmit,
}: ChatWindowProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  if (!isOpen) return null;

  // Only allow free text in AI chat mode
  const allowFreeText = flowState === "ai_chat";

  return (
    <div className="fixed bottom-24 right-4 sm:right-6 w-[calc(100%-2rem)] sm:w-[400px] max-h-[600px] bg-card rounded-2xl chat-shadow animate-slide-up flex flex-col overflow-hidden z-50 border border-border/50">
      {/* Header */}
      <div className="gradient-primary px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={braouLogo} alt="BRAOU" className="w-10 h-10 rounded-full object-contain bg-white" />
          <div>
            <h3 className="font-semibold text-primary-foreground">BRAOU Assistant</h3>
            <p className="text-xs text-primary-foreground/80">
              {flowState === "ai_chat" ? "AI Chat Mode" : "Always here to help"}
            </p>
          </div>
        </div>
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 h-8 w-8"
          >
            <Minimize2 className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 h-8 w-8"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 chat-scrollbar bg-gradient-to-b from-primary-light/30 to-background">
        {messages.map((msg, idx) => (
          <ChatMessage
            key={msg.id}
            message={msg.text}
            isBot={msg.isBot}
            timestamp={msg.timestamp}
            actions={msg.actions}
            formFields={msg.formFields}
            formId={msg.formId}
            onAction={onAction}
            onFormSubmit={onFormSubmit}
            isLatest={idx === messages.length - 1 || (msg.isBot && idx === (() => { for (let i = messages.length - 1; i >= 0; i--) { if (messages[i].isBot) return i; } return -1; })())}
          />
        ))}
        {isTyping && <TypingIndicator />}
        <div ref={messagesEndRef} />
      </div>

      {/* Input - only in AI chat mode */}
      {allowFreeText ? (
        <ChatInput onSend={onSendMessage} disabled={isTyping} />
      ) : (
        <div className="px-4 py-3 border-t border-border/50 bg-card">
          <p className="text-xs text-muted-foreground text-center">
            Select an option above to continue
          </p>
        </div>
      )}
    </div>
  );
};
