import { Button } from "@/components/ui/button";

interface QuickActionsProps {
  onActionClick: (action: string) => void;
}

const quickActions = [
  "Admission Process",
  "Course Details",
  "Exam Schedule",
  "Hall Ticket",
  "Location",
  "Exam Notification",
  "Fee Structure",
  "Contact Support",
];

export const QuickActions = ({ onActionClick }: QuickActionsProps) => {
  return (
    <div className="flex flex-wrap gap-2 px-4 py-3 border-t border-border/50">
      {quickActions.map((action) => (
        <Button
          key={action}
          variant="quickAction"
          size="sm"
          onClick={() => onActionClick(action)}
          className="px-3 py-1 h-auto"
        >
          {action}
        </Button>
      ))}
    </div>
  );
};
