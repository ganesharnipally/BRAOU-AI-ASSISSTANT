

## Analysis

After reviewing the codebase, most of what's requested is **already implemented**:
- Logo is in the header, hero, chatbot window, and chatbot avatar
- Location link is in the footer, contact section, and chatbot system prompt
- Hall ticket, exam notification, and exam application links are in the chatbot system prompt
- Links open in new tabs with proper styling
- Markdown rendering with clickable links is working in chat messages

## What still needs updating

### 1. Feature cards need links (partially reverted)
The feature cards in the "How Can We Help You?" section are plain `<div>`s without links. They should be clickable `<a>` tags linking to official BRAOU pages.

### 2. Add more quick action buttons to chatbot
Add "Hall Ticket", "Location", and "Exam Notification" as quick action options so users can tap them directly.

### 3. Add study centre link to chatbot system prompt
The study centre link (`https://braou.ac.in/studycentre/2#gsc.tab=0`) should be added to the edge function's `BRAOU_LINKS` and system prompt.

### 4. Add header navigation bar
The header section (lines 10-26) is currently empty. Add a proper header with the logo (clickable, links to homepage) and key navigation links (Admissions, Courses, Exams, Contact).

## Implementation Steps

1. **`src/pages/Index.tsx`** — Add a sticky header with logo + nav links. Convert feature cards from `<div>` to `<a>` tags with official BRAOU URLs for each card (Courses, Admissions, Study Centers, Exams).

2. **`src/components/chat/QuickActions.tsx`** — Add "Hall Ticket", "Location", and "Exam Notification" to the quick actions array.

3. **`supabase/functions/chat/index.ts`** — Add `study_centre` link to `BRAOU_LINKS`. Add a study centre structured response section to the system prompt. Redeploy the edge function.

